package com.project.Telecom.Controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Telecom.Dto.ComplaintDto;

import com.project.Telecom.Entity.Complaint;

import com.project.Telecom.Service.ComplaintService;

@RestController
public class ComplaintController {
	@Autowired
	ComplaintService complaintService;
	@Autowired
	ModelMapper modelMapper;
	
	@PostMapping("/api/complaints")
	public void add(ComplaintDto complaintdto) {
		Complaint complaint=modelMapper.map(complaintdto,Complaint.class);
		complaintService.add(complaint);
	}

}
