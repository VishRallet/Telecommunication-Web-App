package com.project.Telecom.Dto;

import java.time.LocalDateTime;

import com.project.Telecom.Entity.Status;



public class ComplaintDto {
	Long id;

	
    String Title;
	
	String description;
	
	Status ComplaintStatus;
	
	LocalDateTime Created_At;
	
	LocalDateTime resolved_At;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Status getComplaintStatus() {
		return ComplaintStatus;
	}

	public void setComplaintStatus(Status complaintStatus) {
		ComplaintStatus = complaintStatus;
	}

	public LocalDateTime getCreated_At() {
		return Created_At;
	}

	public void setCreated_At(LocalDateTime created_At) {
		Created_At = created_At;
	}

	public LocalDateTime getResolved_At() {
		return resolved_At;
	}

	public void setResolved_At(LocalDateTime resolved_At) {
		this.resolved_At = resolved_At;
	}

	@Override
	public String toString() {
		return "ComplaintDto [id=" + id + ", Title=" + Title + ", description=" + description + ", ComplaintStatus="
				+ ComplaintStatus + ", Created_At=" + Created_At + ", resolved_At=" + resolved_At + "]";
	}

	public ComplaintDto(Long id, String title, String description, Status complaintStatus, LocalDateTime created_At,
			LocalDateTime resolved_At) {
		super();
		this.id = id;
		Title = title;
		this.description = description;
		ComplaintStatus = complaintStatus;
		Created_At = created_At;
		this.resolved_At = resolved_At;
	}

	public ComplaintDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
}
