package com.project.Telecom.Entity;

public enum ComplaintStatus {
	open,Inprogress,Resolved;

}
