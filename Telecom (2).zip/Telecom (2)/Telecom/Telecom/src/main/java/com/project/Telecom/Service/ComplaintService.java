package com.project.Telecom.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Telecom.Entity.Complaint;


import com.project.Telecom.Repository.ComplaintRepository;


import jakarta.transaction.Transactional;

@Service
@Transactional

public class ComplaintService {
	
	@Autowired
    ComplaintRepository  complaintRepository;
	
	public void add(Complaint complaint) {
		complaintRepository.save(complaint);
	}
	
	
		
}
