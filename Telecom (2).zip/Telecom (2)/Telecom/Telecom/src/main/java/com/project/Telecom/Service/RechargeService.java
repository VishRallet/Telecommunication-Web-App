package com.project.Telecom.Service;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.project.Telecom.Entity.Plan;
//import com.project.Telecom.Entity.Recharge;
//import com.project.Telecom.Repository.PlanRepository;
//import com.project.Telecom.Repository.RechargeRepository;
//
//import jakarta.transaction.Transactional;
//@Service
//@Transactional
public class RechargeService {
//	@Autowired
//	RechargeRepository rechargeRepository;
//	
//	public void add(Recharge recharge) {
//		rechargeRepository.save(recharge);
//	}
}
