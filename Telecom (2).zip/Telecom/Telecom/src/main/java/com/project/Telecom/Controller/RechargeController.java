package com.project.Telecom.Controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.Telecom.Dto.RechargeDto;
import com.project.Telecom.Entity.Recharge;
import com.project.Telecom.Service.RechargeService;

public class RechargeController {@Autowired
	RechargeService rechargeService;
	@Autowired
	ModelMapper modelMapper;
	
	@PostMapping("/api/recharge")
	public void add(RechargeDto rechargedto) {
		Recharge recharge=modelMapper.map(rechargedto,Recharge.class);
		rechargeService.add(recharge);
	}

}
