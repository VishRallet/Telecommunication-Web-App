package com.project.Telecom.Entity;

public enum PlanType {
	data,voice,combo;

}
