package com.project.Telecom.Entity;

public enum Status {
	success,failure;

}
