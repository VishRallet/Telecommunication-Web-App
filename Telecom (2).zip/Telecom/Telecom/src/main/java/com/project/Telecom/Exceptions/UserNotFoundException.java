package com.project.Telecom.Exceptions;

public class UserNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNotFoundException() {
	//	super();
		// TODO Auto-generated constructor stub
	}

}
