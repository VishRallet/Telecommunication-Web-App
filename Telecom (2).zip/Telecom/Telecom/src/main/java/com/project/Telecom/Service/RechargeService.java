package com.project.Telecom.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.Telecom.Entity.Plan;
import com.project.Telecom.Entity.Recharge;
import com.project.Telecom.Repository.PlanRepository;
import com.project.Telecom.Repository.RechargeRepository;

public class RechargeService {
	@Autowired
	RechargeRepository rechargeRepository;
	
	public void add(Recharge recharge) {
		rechargeRepository.save(recharge);
	}
}
