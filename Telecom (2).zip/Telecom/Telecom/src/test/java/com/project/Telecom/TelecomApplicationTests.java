package com.project.Telecom;



@SpringBootTest
public class TelecomApplicationTests {

	@Test
	void contextLoads() {
	}

}
