package com.mobile.controller;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.mobile.dto.MobileDTO;
import com.mobile.entity.Mobile;
import com.mobile.exceptions.MobileNotFoundException;
import com.mobile.service.MobileService;
@RestController
public class MobileController {
	@Autowired
	MobileService mobileService;
	@Autowired
	ModelMapper modelMapper;
	@PostMapping("/mobile")
	public String addMobile(@RequestBody MobileDTO mobileDto) {   
		Mobile mobile=modelMapper.map(mobileDto,Mobile.class);
		mobileService.addMobile(mobile);
		return "Added";
	}
	@GetMapping("/mobile/{id}")
	public MobileDTO getMobile(@PathVariable("id") Integer id) throws MobileNotFoundException{
		Mobile mobile=mobileService.getMobile(id);
		return modelMapper.map(mobile, MobileDTO.class);
	}
	@GetMapping("/mobile")
	public List<MobileDTO> getAllMobiles() {
		List<Mobile> mobileList= mobileService.getAllMobiles();
		return mobileList.stream().map(Mobile->modelMapper.map(Mobile,MobileDTO.class)).collect(Collectors.toList());
	}
	@PutMapping("/mobile/{id}")
	public String updateMobile(@PathVariable("id") Integer id,@RequestBody MobileDTO mobileDTO)  throws Exception{
		mobileService.updateMobile(id,modelMapper.map(mobileDTO, Mobile.class));
		 return "updated";
	}
	@DeleteMapping("/mobile/{id}")
	public String deleteMobile(@PathVariable("id") Integer id) throws MobileNotFoundException {
		mobileService.deleteMobile(id);
		 return "deleted";
	}
}