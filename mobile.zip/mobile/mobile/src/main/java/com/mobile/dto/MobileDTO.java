package com.mobile.dto;
public class MobileDTO {
	Long id;
	String name,mobileNumber,planType,region;
	public MobileDTO() {
	}
	public MobileDTO(Long id, String name, String mobileNumber, String planType, String region) {
		this.id = id;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.planType = planType;
		this.region = region;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	@Override
	public String toString() {
		return "mobileDTO [id=" + id + ", name=" + name + ", mobileNumber=" + mobileNumber + ", planType=" + planType
				+ ", region=" + region + "]";
	}
}
