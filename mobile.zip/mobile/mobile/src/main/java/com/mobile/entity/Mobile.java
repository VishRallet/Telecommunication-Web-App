package com.mobile.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
@Entity
@Table(name="Mobile")
public class Mobile {
	@Id
	@Column(name="id")
	Long id;
	@Column(name="name")
	String name;
	@Column(name="mobileNumber")
	String mobileNumber;
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name="planType")
	PlanType planType;
	@Column(name="region")
	String region;
	public Mobile() {
	}
	public Mobile(Long id, String name, String mobileNumber, PlanType planType, String region) {
		this.id = id;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.planType = planType;
		this.region = region;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public PlanType getPlanType() {
		return planType;
	}
	public void setPlanType(PlanType planType) {
		this.planType = planType;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	@Override
	public String toString() {
		return "Mobile [id=" + id + ", name=" + name + ", mobileNumber=" + mobileNumber + ", planType=" + planType
				+ ", region=" + region + "]";
	}
}