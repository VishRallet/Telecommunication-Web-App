package com.mobile.entity;
public enum PlanType {
    PREPAID,POSTPAID
}