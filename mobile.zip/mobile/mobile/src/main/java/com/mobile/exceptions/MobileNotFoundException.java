package com.mobile.exceptions;
public class MobileNotFoundException extends RuntimeException {
	public MobileNotFoundException(String s) {
		super(s);
	}
}