package com.mobile.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mobile.entity.Mobile;
import com.mobile.exceptions.MobileNotFoundException;
import com.mobile.exceptions.ResourceNotFoundException;
import com.mobile.repository.MobileRepository;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class MobileService {
	@Autowired
	MobileRepository mobileRepository;
	public void addMobile(Mobile mobile) {
		mobileRepository.save(mobile);
	}
	public List<Mobile> getAllMobiles() {
		return (List)mobileRepository.findAll();
	}
	public Mobile getMobile(Integer id) throws MobileNotFoundException {
		Mobile mobile=mobileRepository.findById(id).orElseThrow(()->new MobileNotFoundException("Mobile not found!"));
		return mobile;
	}
	public void deleteMobile(Integer id) throws MobileNotFoundException {
		Mobile mobile=mobileRepository.findById(id).orElseThrow(()->new MobileNotFoundException("Mobile not found!"));
		if(mobile!=null)
			mobileRepository.deleteById(id);
	}
	public void updateMobile(Integer id,Mobile mobile) throws ResourceNotFoundException {
		Mobile mobile1=mobileRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Mobile","id",id));
		mobile1.setPlanType(mobile.getPlanType());
	}
}