import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

export default function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        
        {/* Prepaid Pages */}
        <Route path="/prepaid/recharge" element={<PrepaidRecharge />} />
        <Route path="/prepaid/plans" element={<PrepaidPlans />} />
        
        {/* Postpaid Pages */}
        <Route path="/postpaid/bill" element={<PostpaidBill />} />
        <Route path="/postpaid/plans" element={<PostpaidPlans />} />
        
        {/* Account Pages */}
        <Route path="/account/profile" element={<Profile />} />
        <Route path="/account/signin" element={<SignIn />} />
        <Route path="/account/settings" element={<Settings />} />
      </Routes>
    </Router>
  );
}

// Navbar Component
function Navbar() {
  const [prepaidOpen, setPrepaidOpen] = useState(false);
  const [postpaidOpen, setPostpaidOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);

  return (
    <nav style={styles.navbar}>
      <h2 style={styles.logo}>VI-SIM</h2>

      <div style={styles.links}>
        <Link to="/" style={styles.link}>Home</Link>

        {/* Prepaid Dropdown */}
        <div
          style={styles.dropdown}
          onMouseEnter={() => setPrepaidOpen(true)}
          onMouseLeave={() => setPrepaidOpen(false)}
        >
          <span style={styles.link}>Prepaid ▾</span>
          {prepaidOpen && (
            <div style={styles.dropdownMenu}>
              <Link to="/prepaid/recharge" style={styles.dropdownItem}>Recharge</Link>
              <Link to="/prepaid/plans" style={styles.dropdownItem}>Plans</Link>
            </div>
          )}
        </div>

        {/* Postpaid Dropdown */}
        <div
          style={styles.dropdown}
          onMouseEnter={() => setPostpaidOpen(true)}
          onMouseLeave={() => setPostpaidOpen(false)}
        >
          <span style={styles.link}>Postpaid ▾</span>
          {postpaidOpen && (
            <div style={styles.dropdownMenu}>
              <Link to="/postpaid/bill" style={styles.dropdownItem}>Pay Bill</Link>
              <Link to="/postpaid/plans" style={styles.dropdownItem}>Plans</Link>
            </div>
          )}
        </div>
      </div>

      {/* Account Dropdown */}
      <div
        style={styles.dropdown}
        onMouseEnter={() => setAccountOpen(true)}
        onMouseLeave={() => setAccountOpen(false)}
      >
        <span style={styles.link}>Account ▾</span>
        {accountOpen && (
          <div style={styles.dropdownMenuRight}>
            <Link to="/account/profile" style={styles.dropdownItem}>Profile</Link>
            <Link to="/account/signin" style={styles.dropdownItem}>Sign In</Link>
            <Link to="/account/settings" style={styles.dropdownItem}>Settings</Link>
          </div>
        )}
      </div>
    </nav>
  );
}

// Pages
function Home() {
  return <h1 style={styles.page}>Welcome to VI-SIM 🚀</h1>;
}

// Prepaid Pages
function PrepaidRecharge() {
  return <h1 style={styles.page}>Recharge your Prepaid Number 💳</h1>;
}
function PrepaidPlans() {
  return <h1 style={styles.page}>Check out Prepaid Plans 📱</h1>;
}

// Postpaid Pages
function PostpaidBill() {
  return <h1 style={styles.page}>Pay your Postpaid Bill 💼</h1>;
}
function PostpaidPlans() {
  return <h1 style={styles.page}>Explore Postpaid Plans 📄</h1>;
}

// Account Pages
function Profile() {
  return <h1 style={styles.page}>Your Profile 👤</h1>;
}
function SignIn() {
  return <h1 style={styles.page}>Sign In to Your Account 🔑</h1>;
}
function Settings() {
  return <h1 style={styles.page}>Account Settings ⚙️</h1>;
}

// Inline styles
const styles = {
  navbar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    background: "#007bff",
    padding: "10px 20px",
    color: "white",
  },
  logo: { margin: 0 },
  links: { display: "flex", gap: "20px" },
  link: { color: "white", textDecoration: "none", cursor: "pointer" },
  dropdown: { position: "relative" },
  dropdownMenu: {
    position: "absolute",
    top: "100%",
    left: 0,
    background: "white",
    color: "black",
    padding: "10px",
    borderRadius: "5px",
    boxShadow: "0 2px 5px rgba(0,0,0,0.2)",
    zIndex: 1000,
  },
  dropdownMenuRight: {
    position: "absolute",
    top: "100%",
    right: 0,
    background: "white",
    color: "black",
    padding: "10px",
    borderRadius: "5px",
    boxShadow: "0 2px 5px rgba(0,0,0,0.2)",
    zIndex: 1000,
  },
  dropdownItem: { display: "block", padding: "5px 10px", textDecoration: "none", color: "black" },
  page: { padding: "20px", textAlign: "center" },
};
